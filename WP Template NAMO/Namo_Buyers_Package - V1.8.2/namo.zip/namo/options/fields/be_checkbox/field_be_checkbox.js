jQuery(document).ready(function(){
	jQuery('.on-off-button').checkbox();
});